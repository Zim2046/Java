public class PersonallyIdentifableInfo {
//  👇 A fucntion that belongs to a class -> a main method
//  |<--'function' -->| 
//  |<-- keyword   -->|  👇 name of function
    public static void main(String[] args) {
                           //👆arguments👆
        System.out.println("My name is Jake DoeDoe. ");
        System.out.println("I am a 21 years old. ");
        System.out.println("My hometown is Glendale, CA. ");
    }
} 
